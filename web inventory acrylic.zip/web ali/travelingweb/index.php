<?php include('db.php'); ?>
<?php include('header.php'); 

require_once 'libs/phpqrcode-master/qrlib.php'; ?>

<div class="container mt-4">
    <div class="row">
        <?php
        if (isset($_GET['id'])) {
            // Bagian booking
            $id = $_GET['id'];
            $stmt = $pdo->prepare("SELECT * FROM destinasi WHERE id = ?");
            $stmt->execute([$id]);
            $destinasi = $stmt->fetch();

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $nama = $_POST['nama'];
                $email = $_POST['email'];
                $tanggal = $_POST['tanggal'];
                $jumlah_tiket = $_POST['jumlah_tiket'];
                $total_harga = $jumlah_tiket * $destinasi['harga'];

                // Simpan pemesanan tiket
                $stmt = $pdo->prepare("INSERT INTO tiket (nama, email, destinasi_id, tanggal_booking, jumlah_tiket, total_harga) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nama, $email, $id, $tanggal, $jumlah_tiket, $total_harga]);

                // Dapatkan ID tiket terakhir yang disimpan
                $tiket_id = $pdo->lastInsertId();

                // Generate QR Code
                $qr_data = "Nama: $nama\nEmail: $email\nDestinasi: " . $destinasi['nama_destinasi'] . "\nTanggal: $tanggal\nJumlah Tiket: $jumlah_tiket\nTotal Harga: Rp" . number_format($total_harga, 0, ',', '.');
                $qr_file = 'qrcodes/ticket_' . $tiket_id . '.png'; // Pastikan folder ini ada

                // Buat QR Code dan simpan ke file
                QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 4); // Sesuaikan level error correction dan ukuran jika perlu

        echo "<div class='alert alert-success'>Tiket berhasil dipesan! QR Code telah dihasilkan.</div>";
        echo "<img src='$qr_file' alt='QR Code' style='width: 150px; height: 150px;'>"; // Tampilkan QR Code
    }
?>
        <h2>Booking Tiket - <?php echo htmlspecialchars($destinasi['nama_destinasi']); ?></h2>
        <form method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Booking</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" required>
            </div>
            <div class="mb-3">
                <label for="jumlah_tiket" class="form-label">Jumlah Tiket</label>
                <input type="number" class="form-control" id="jumlah_tiket" name="jumlah_tiket" required>
            </div>
            <button type="submit" class="btn btn-primary">Pesan Sekarang</button>
        </form>
        <?php } 
        else {
            // Bagian tampil destinasi
            $stmt = $pdo->query("SELECT * FROM destinasi");
            while ($row = $stmt->fetch()) {
                echo '
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="'. htmlspecialchars($row['gambar']) .'" class="card-img-top" alt="'. htmlspecialchars($row['nama_destinasi']) .'">
                        <div class="card-body">
                            <h5 class="card-title">'. htmlspecialchars($row['nama_destinasi']) .'</h5>
                            <p class="card-text">'. htmlspecialchars($row['deskripsi']) .'</p>
                            <p>Harga: Rp'. number_format($row['harga'], 0, ',', '.') .'</p>
                            <a href="?id='. $row['id'] .'" class="btn btn-primary">Booking</a>
                        </div>
                    </div>
                </div>
                ';
            }
        } ?>
    </div>
</div>

<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect ke halaman login jika belum login
    header("Location: login.php");
    exit();
}
?>
<?php include('db.php'); ?>


<!-- Konten Halaman Utama -->

<?php include('footer.php');?>