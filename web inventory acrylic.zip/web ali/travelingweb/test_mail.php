<?php
$to = "gempahfarm@gmail.com"; // Ganti dengan email penerima yang valid
$subject = "Test Email";
$message = "This is a test email.";
$headers = "From: ihzanudinali5@gmail.com"; // Ganti dengan email pengirim yang valid

if (mail($to, $subject, $message, $headers)) {
    echo "Email successfully sent.";
} else {
    echo "Email failed to send.";
}
