<?php
phpinfo();
?>
