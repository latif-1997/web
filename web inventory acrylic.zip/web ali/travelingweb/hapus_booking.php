<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Query untuk menghapus booking berdasarkan ID
    $stmt = $pdo->prepare("DELETE FROM tiket WHERE id = ?");
    $stmt->execute([$id]);
    
    // Redirect kembali ke halaman admin setelah penghapusan
    header("Location: pengguna.php?status=deleted");

}
?>
