<?php
session_start(); // Memulai sesi
include('db.php'); // Menginclude file koneksi database

// Cek apakah admin sudah login
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php'); // Redirect ke halaman login jika belum login
    exit(); // Hentikan eksekusi setelah redirect
}

// Logika Logout
if (isset($_POST['logout'])) {
    session_destroy(); // Menghancurkan session
    header('Location: admin_login.php'); // Redirect ke halaman login
    exit(); // Hentikan eksekusi setelah redirect
}

// Logika Penghapusan
if (isset($_POST['hapus_booking'])) {
    $id = $_POST['id']; // Ambil ID yang dikirimkan
    $stmt = $pdo->prepare("DELETE FROM tiket WHERE id = ?");
    $stmt->execute([$id]);
    
    // Redirect ke halaman yang sama untuk refresh data
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wisata Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container mt-4">
    <h2>Data Pemesan Tiket</h2>

    <!-- Tombol Logout -->
    <form method="post" class="mb-3">
        <button type="submit" name="logout" class="btn btn-danger">Logout</button>
    </form>

    <?php
    // Ambil semua data pemesan tiket dari database
    $stmt = $pdo->prepare("SELECT tiket.*, destinasi.nama_destinasi FROM tiket JOIN destinasi ON tiket.destinasi_id = destinasi.id ORDER BY tiket.id DESC");
    $stmt->execute();
    $pemesan = $stmt->fetchAll();

    if ($pemesan) {
        ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemesan</th>
                        <th>Email</th>
                        <th>Destinasi</th>
                        <th>Tanggal Booking</th>
                        <th>Jumlah Tiket</th>
                        <th>Total Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $no = 1;
                foreach ($pemesan as $row) {
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nama']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_destinasi']); ?></td>
                        <td><?php echo htmlspecialchars($row['tanggal_booking']); ?></td>
                        <td><?php echo htmlspecialchars($row['jumlah_tiket']); ?></td>
                        <td>Rp<?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                        <td>
                            <a href="detail_pemesan.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Detail</a>

                            <!-- Form untuk Hapus Data -->
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="hapus_booking" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus booking ini?');">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </div>
        <?php
    } else {
        echo '<p>Belum ada data pemesan tiket.</p>';
    }
    ?>
</div>

<?php include('footer.php'); // Include footer jika ada ?>
</body>
</html>
