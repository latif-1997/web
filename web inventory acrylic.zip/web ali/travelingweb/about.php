<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Wisata Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="index.php">Travelin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="about.php">About</a> <!-- Active di halaman About -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2>Tentang Kami</h2>
    <p>Selamat datang di Wisata Booking, platform terpercaya untuk membantu Anda merencanakan liburan yang tak terlupakan. Kami hadir untuk memberikan kemudahan dan kenyamanan dalam memesan tiket wisata, hotel, dan layanan lainnya.</p>
    
    <h3>Visi Kami</h3>
    <p>Visi kami adalah menjadi penyedia layanan pemesanan wisata terkemuka di dunia, memberikan pengalaman yang menyenangkan dan aman bagi semua pelanggan.</p>
    
    <h3>Misi Kami</h3>
    <ul>
        <li>Menyediakan layanan pelanggan yang luar biasa dan responsif.</li>
        <li>Menawarkan berbagai pilihan paket wisata yang sesuai dengan kebutuhan dan anggaran pelanggan.</li>
        <li>Berinovasi dalam teknologi untuk memudahkan proses pemesanan.</li>
    </ul>

    <h3>Tim Kami</h3>
    <p>Kami memiliki tim yang terdiri dari profesional berpengalaman di industri perjalanan yang siap membantu Anda setiap langkah. Kami berkomitmen untuk memberikan informasi yang akurat dan layanan terbaik.</p>

    <h3>Kontak Kami</h3>
    <p>Jika Anda memiliki pertanyaan atau membutuhkan bantuan, jangan ragu untuk menghubungi kami melalui halaman <a href="contact.php">Contact Us</a>.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
