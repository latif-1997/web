<?php
session_start(); // Memulai sesi
include('db.php'); // Menginclude koneksi database

// Cek apakah admin sudah login
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php'); // Redirect ke halaman login jika belum login
    exit(); // Hentikan eksekusi
}

// Proses pengubahan password
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password_lama = $_POST['password_lama'];
    $password_baru = $_POST['password_baru'];
    $password_baru_konfirmasi = $_POST['password_baru_konfirmasi'];

    // Ambil password admin dari database
    $stmt = $pdo->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->execute([$_SESSION['admin']]); // Asumsikan Anda menyimpan id admin di session
    $admin = $stmt->fetch();

    // Cek password lama
    if ($admin && password_verify($password_lama, $admin['password'])) {
        // Cek konfirmasi password baru
        if ($password_baru === $password_baru_konfirmasi) {
            // Hash password baru dan simpan ke database
            $hashed_password = password_hash($password_baru, PASSWORD_DEFAULT);
            $update_stmt = $pdo->prepare("UPDATE admin SET password = ? WHERE id = ?");
            $update_stmt->execute([$hashed_password, $_SESSION['admin_id']]);

            echo '<p>Password berhasil diubah!</p>';
        } else {
            echo '<p>Password baru dan konfirmasi tidak sama.</p>';
        }
    } else {
        echo '<p>Password lama tidak valid.</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Ubah Password Admin</h2>
    <form method="post">
        <div class="mb-3">
            <label for="password_lama" class="form-label">Password Lama</label>
            <input type="password" name="password_lama" id="password_lama" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password_baru" class="form-label">Password Baru</label>
            <input type="password" name="password_baru" id="password_baru" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password_baru_konfirmasi" class="form-label">Konfirmasi Password Baru</label>
            <input type="password" name="password_baru_konfirmasi" id="password_baru_konfirmasi" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Ubah Password</button>
    </form>
</div>

<?php include('footer.php'); // Menginclude footer jika ada ?>
</body>
</html>
