<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load PHPMailer using Composer

// Ambil data dari form
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Inisialisasi PHPMailer
$mail = new PHPMailer(true);

try {
    // Pengaturan server
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';                 // Tentukan SMTP server
    $mail->SMTPAuth   = true;                             // Aktifkan autentikasi SMTP
    $mail->Username   = '411211045@mahasiswa.undira.ac.id'; // Alamat email SMTP
    $mail->Password   = '411211045';              // Kata sandi SMTP atau App Password jika menggunakan Gmail
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;   // Aktifkan enkripsi TLS
    $mail->Port       = 587;                              // Port yang digunakan oleh server SMTP

    // Penerima email
    $mail->setFrom($email, $name);                        // Dari siapa email dikirim
    $mail->addAddress('411211045@mahasiswa.undira.ac.id'); // Email admin yang dituju

    // Konten email
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Pesan dari Form Travelin';
    $mail->Body    = "<h3>Nama: $name</h3><p>Email: $email</p><p>Pesan: $message</p>";
    $mail->AltBody = "Nama: $name\nEmail: $email\nPesan: $message";

    // Kirim email
    $mail->send();
    // Tampilkan halaman sukses
    header('Location: success.php');
    exit;
} catch (Exception $e) {
    echo "Pesan gagal dikirim. Error: {$mail->ErrorInfo}";
}
?>
