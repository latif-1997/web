<?php
// Menghubungkan ke database
include('db.php');

// Ganti 'admin' dan 'password' dengan username dan password yang Anda inginkan
$username = 'travelin';
$password = 'travelingaja'; // Password asli

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Menyimpan admin ke database
$stmt = $pdo->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
$stmt->execute([$username, $hashedPassword]);

echo "Admin berhasil ditambahkan!";
?>
