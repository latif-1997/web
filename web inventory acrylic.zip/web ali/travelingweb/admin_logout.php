<?php
session_start();// Memulai sesi
session_destroy();// Menghancurkan semua sesi
header('Location: admin_login.php'); // Redirect ke halaman login
exit(); // Hentikan eksekusi
?>
