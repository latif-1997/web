<?php include('db.php'); ?>
<?php include('header.php'); ?>

<div class="container mt-4">
    <h2>Pembayaran Tiket</h2>
    
    <?php
    if (isset($_GET['id'])) {
        $bookingId = $_GET['id'];
        // Ambil data booking berdasarkan ID
        $stmt = $pdo->prepare("SELECT tiket.*, destinasi.nama_destinasi FROM tiket JOIN destinasi ON tiket.destinasi_id = destinasi.id WHERE tiket.id = ?");
        $stmt->execute([$bookingId]);
        $row = $stmt->fetch();
        
        if ($row) {
            echo '<h4>Detail Booking</h4>';
            ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Nama</th>
                        <td><?php echo htmlspecialchars($row['nama']); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                    </tr>
                    <tr>
                        <th>Destinasi</th>
                        <td><?php echo htmlspecialchars($row['nama_destinasi']); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Booking</th>
                        <td><?php echo htmlspecialchars($row['tanggal_booking']); ?></td>
                    </tr>
                    <tr>
                        <th>Jumlah Tiket</th>
                        <td><?php echo htmlspecialchars($row['jumlah_tiket']); ?></td>
                    </tr>
                    <tr>
                        <th>Total Harga</th>
                        <td>Rp<?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    </tr>
                </table>
            </div>
            <form method="POST" action="proses_pembayaran.php" class="pembayaran-form" style="background-color: #e0f7fa; padding: 20px; border-radius: 5px;" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $bookingId; ?>">
    
    <h5>Pilih Metode Pembayaran:</h5>
    <div class="form-group">
        <select name="metode_pembayaran" class="form-control" required>
            <option value="Transfer Bank">Bank BCA 01234567 (PT Travelin)</option>
        </select>
    </div>

    <h5>Upload Bukti Pembayaran:</h5>
    <div class="form-group">
        <input type="file" name="bukti_pembayaran" class="form-control-file" accept="image/*" required>
    </div>
                
                <button type="submit" class="btn btn-primary mt-3">Bayar</button>
            </form>
            <?php
        } else {
            echo '<p>Booking tidak ditemukan.</p>';
        }
    } else {
        echo '<p>ID booking tidak disediakan.</p>';
    }
    ?>
</div>

<?php include('footer.php'); ?>
