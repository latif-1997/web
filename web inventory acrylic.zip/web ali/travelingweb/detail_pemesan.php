<?php
session_start(); // Memulai sesi
include('db.php'); // Menginclude koneksi database

// Cek apakah admin sudah login
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php'); // Redirect ke halaman login jika belum login
    exit(); // Hentikan eksekusi
}

// Ambil ID pemesanan dari URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $booking_id = $_GET['id'];

    // Siapkan dan eksekusi query untuk mengambil detail pemesanan
    $stmt = $pdo->prepare("SELECT tiket.*, destinasi.nama_destinasi FROM tiket JOIN destinasi ON tiket.destinasi_id = destinasi.id WHERE tiket.id = ?");
    $stmt->execute([$booking_id]);
    $detail = $stmt->fetch();

    if (!$detail) {
        echo '<p>Data pemesanan tidak ditemukan.</p>';
        exit();
    }
} else {
    echo '<p>ID pemesanan tidak valid.</p>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pemesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container mt-4">
    <h2>Detail Pemesanan Tiket</h2>

    <table class="table table-bordered">
        <tr>
            <th>Nama Pemesan</th>
            <td><?php echo htmlspecialchars($detail['nama']); ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo htmlspecialchars($detail['email']); ?></td>
        </tr>
        <tr>
            <th>Destinasi</th>
            <td><?php echo htmlspecialchars($detail['nama_destinasi']); ?></td>
        </tr>
        <tr>
            <th>Tanggal Booking</th>
            <td><?php echo htmlspecialchars($detail['tanggal_booking']); ?></td>
        </tr>
        <tr>
            <th>Jumlah Tiket</th>
            <td><?php echo htmlspecialchars($detail['jumlah_tiket']); ?></td>
        </tr>
        <tr>
            <th>Total Harga</th>
            <td>Rp<?php echo number_format($detail['total_harga'], 0, ',', '.'); ?></td>
        </tr>
    </table>

    <!-- Tombol untuk kembali ke daftar pemesan -->
    <a href="admin_data_pemesan.php" class="btn btn-primary">Kembali ke Data Pemesan</a>
</div>

<?php include('footer.php'); // Menginclude footer jika ada ?>
</body>
</html>
