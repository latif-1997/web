<?php include('db.php'); ?>
<?php include('header.php'); ?>

<div class="container mt-4">
    <h2>Pembayaran Berhasil</h2>
    <p>Terima kasih! Pembayaran Anda telah berhasil.</p>
</div>

<?php include('footer.php'); ?>
