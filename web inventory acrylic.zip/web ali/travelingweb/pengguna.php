<?php include('db.php'); ?>
<?php include('header.php'); ?>

<div class="container mt-4">
    <h2>Daftar Booking Tiket</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Destinasi</th>
                <th>Tanggal Booking</th>
                <th>Jumlah Tiket</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
    <?php
    $stmt = $pdo->query("SELECT tiket.*, destinasi.nama_destinasi FROM tiket JOIN destinasi ON tiket.destinasi_id = destinasi.id");
    $no = 1;
    while ($row = $stmt->fetch()) {
        $qrCodeFilePath = 'qrcodes/ticket_' . $row['id'] . '.png'; // Pastikan file ini ada
        echo '
        <tr>
            <td>' . $no++ . '</td>
            <td>' . htmlspecialchars($row['nama']) . '</td>
            <td>' . htmlspecialchars($row['email']) . '</td>
            <td>' . htmlspecialchars($row['nama_destinasi']) . '</td>
            <td>' . htmlspecialchars($row['tanggal_booking']) . '</td>
            <td>' . htmlspecialchars($row['jumlah_tiket']) . '</td>
            <td>Rp' . number_format($row['total_harga'], 0, ',', '.') . '</td>
           <td>
    <img src="' . $qrCodeFilePath . '" alt="QR Code" style="width: 100px; height: 100px;">
    <a href="pembayaran.php?id=' . $row['id'] . '" class="btn btn-success btn-sm">Bayar</a>
    <a href="hapus_booking.php?id=' . $row['id'] . '" class="btn btn-danger btn-sm">Hapus</a>
</td>         
        </tr>
        ';
        }
        ?>
     </tbody>
    </table>
</div>
<?php
if (isset($_GET['status']) && $_GET['status'] == 'deleted') {
    echo "<div class='alert alert-success'>Booking berhasil dihapus!</div>";
}
?>
<script>
    // Konfirmasi sebelum hapus
    document.querySelectorAll('.btn-danger').forEach(button => {
        button.addEventListener('click', function(event) {
            if (!confirm("Apakah Anda yakin ingin menghapus booking ini?")) {
                event.preventDefault(); // Batalkan aksi jika tidak setuju
            }
        });
    });
</script>

<?php include('footer.php'); ?>
