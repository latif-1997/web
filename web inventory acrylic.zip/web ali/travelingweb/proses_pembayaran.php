<?php
// Include file koneksi ke database
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bookingId = $_POST['id'];
    $metodePembayaran = $_POST['metode_pembayaran'];

    // Cek jika file diupload
    if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] == 0) {
        $fileTmpPath = $_FILES['bukti_pembayaran']['tmp_name'];
        $fileName = $_FILES['bukti_pembayaran']['name'];
        $fileSize = $_FILES['bukti_pembayaran']['size'];
        $fileType = $_FILES['bukti_pembayaran']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $allowedfileExtensions = array('jpg', 'png', 'jpeg', 'pdf');

        if (in_array($fileExtension, $allowedfileExtensions)) {
            // Directory untuk menyimpan bukti pembayaran
            $uploadFileDir = './uploads/';
            $dest_path = $uploadFileDir . $fileName;

            // Pindahkan file dari temporary ke directory tujuan
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                // Simpan informasi pembayaran dan path file ke database
                $stmt = $pdo->prepare("INSERT INTO pembayaran (booking_id, metode_pembayaran, bukti_pembayaran) VALUES (?, ?, ?)");
                $stmt->execute([$bookingId, $metodePembayaran, $dest_path]);

                echo 'Pembayaran berhasil dan bukti pembayaran telah diunggah.';
            } else {
                echo 'Terjadi kesalahan saat mengupload file.';
            }
        } else {
            echo 'Tipe file tidak diizinkan. Harap unggah file gambar atau PDF.';
        }
    } else {
        echo 'Harap unggah bukti pembayaran.';
    }
}

// Jika pembayaran berhasil, update status pembayaran
$stmt = $pdo->prepare("UPDATE tiket SET status_pembayaran = 'Lunas', metode_pembayaran = ? WHERE id = ?");
$stmt->execute([$metodePembayaran, $bookingId]);

// Redirect ke halaman booking atau halaman lain dengan notifikasi
header("Location: pembayaran_sukses.php?status=pembayaran_berhasil");
exit();
{
echo "Metode request tidak valid.";
}
?>
