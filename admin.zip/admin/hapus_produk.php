<?php
// Sertakan file koneksi database
include '../koneksi.php';

// Periksa apakah parameter ID produk diterima dari URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus produk berdasarkan ID
    $query_delete_product = "DELETE FROM products WHERE id = $id";

    if ($koneksi->query($query_delete_product)) {
        // Redirect kembali ke halaman stok_produk.php setelah berhasil menghapus
        header('Location: stock_product.php');
        exit;
    } else {
        // Tangani kesalahan jika query gagal
        die('Query error: ' . $koneksi->error);
    }
} else {
    // Redirect ke halaman stok_produk.php jika tidak ada ID produk yang diterima
    header('Location: stock_product.php');
    exit;
}
?>