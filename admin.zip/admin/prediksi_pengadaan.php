<?php
include 'header.php';
include '../koneksi.php';

$tanggal_dari = '';
$tanggal_sampai = '';
$data_pengeluaran = [];
$prediksi_kebutuhan = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit_filter'])) {
        $tanggal_dari = isset($_POST['tanggal_dari']) ? date('Y-m-d', strtotime($_POST['tanggal_dari'])) : '';
        $tanggal_sampai = isset($_POST['tanggal_sampai']) ? date('Y-m-d', strtotime($_POST['tanggal_sampai'])) : '';

        $query_pengeluaran = "SELECT products.name, stock_history.quantity, stock_history.date 
                              FROM stock_history 
                              JOIN products ON stock_history.product_id = products.id 
                              WHERE stock_history.action_type = 'out' 
                              AND stock_history.date BETWEEN '$tanggal_dari' AND '$tanggal_sampai'";
        $result_pengeluaran = mysqli_query($koneksi, $query_pengeluaran);

        if (!$result_pengeluaran) {
            die('Query error: ' . mysqli_error($koneksi));
        }

        if (mysqli_num_rows($result_pengeluaran) > 0) {
            while ($row = mysqli_fetch_assoc($result_pengeluaran)) {
                $data_pengeluaran[] = $row;
            }
        }
    }

    if (isset($_POST['submit_prediksi'])) {
        $tanggal_dari = $_POST['tanggal_dari'];
        $tanggal_sampai = $_POST['tanggal_sampai'];
        $data_pengeluaran = json_decode($_POST['data_pengeluaran'], true);

        // Menghitung prediksi kebutuhan per produk
        $total_pengeluaran = [];
        foreach ($data_pengeluaran as $row) {
            if (!isset($total_pengeluaran[$row['name']])) {
                $total_pengeluaran[$row['name']] = 0;
            }
            $total_pengeluaran[$row['name']] += $row['quantity'];
        }

        foreach ($total_pengeluaran as $name => $quantity) {
            $prediksi_kebutuhan[] = [
                'name' => $name,
                'quantity' => $quantity / count($total_pengeluaran)
            ];
        }
    }
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            PREDIKSI PENGADAAN BARANG
            <small>Data Prediksi Pengadaan Barang</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Prediksi Pengadaan Barang</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <section class="col-lg-12">
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title">Filter Pengeluaran Barang</h3>
                    </div>
                    <div class="box-body">
                        <form method="post" action="">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Mulai Tanggal</label>
                                        <input autocomplete="off" type="text" name="tanggal_dari" class="form-control datepicker2" placeholder="Mulai Tanggal" required="required">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Sampai Tanggal</label>
                                        <input autocomplete="off" type="text" name="tanggal_sampai" class="form-control datepicker2" placeholder="Sampai Tanggal" required="required">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <br/>
                                        <input type="submit" value="TAMPILKAN DATA" name="submit_filter" class="btn btn-sm btn-primary">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if (isset($_POST['submit_filter']) && !empty($data_pengeluaran)) : ?>
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title">Data Pengeluaran Barang</h3>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="table-data">
                                    <thead>
                                        <tr>
                                            <th width="1%">NO</th>
                                            <th>TANGGAL</th>
                                            <th>NAMA BARANG</th>
                                            <th>JUMLAH</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        foreach ($data_pengeluaran as $row) {
                                            ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $row['date']; ?></td>
                                                <td><?php echo $row['name']; ?></td>
                                                <td><?php echo $row['quantity']; ?></td>
                                            </tr>
                                            <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <form method="post" action="">
                        <input type="hidden" name="tanggal_dari" value="<?php echo htmlspecialchars($tanggal_dari); ?>">
                        <input type="hidden" name="tanggal_sampai" value="<?php echo htmlspecialchars($tanggal_sampai); ?>">
                        <input type="hidden" name="data_pengeluaran" value="<?php echo htmlspecialchars(json_encode($data_pengeluaran)); ?>">
                        <input type="submit" value="PREDIKSI PENGADAAN" name="submit_prediksi" class="btn btn-sm btn-primary">
                    </form>
                <?php endif; ?>

                <?php if (isset($_POST['submit_prediksi']) && !empty($prediksi_kebutuhan)) : ?>
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title">Prediksi Pengadaan Barang</h3>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th width="1%">NO</th>
                                            <th>NAMA BARANG</th>
                                            <th>PREDIKSI KEBUTUHAN</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        foreach ($prediksi_kebutuhan as $row) {
                                            ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $row['name']; ?></td>
                                                <td><?php echo round($row['quantity']); ?></td>
                                            </tr>
                                            <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                            <a href="cetak_prediksi.php?tanggal_dari=<?php echo urlencode($tanggal_dari); ?>&tanggal_sampai=<?php echo urlencode($tanggal_sampai); ?>&prediksi=<?php echo urlencode(json_encode($prediksi_kebutuhan)); ?>" target="_blank" class="btn btn-sm btn-success"><i class="fa fa-file-pdf-o"></i> &nbsp CETAK PDF</a>
                        </div>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </section>
</div>

<?php include 'footer.php'; ?>