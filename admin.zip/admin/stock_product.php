<?php
include 'header.php'; // Sertakan header
include '../koneksi.php'; // Sertakan file koneksi

// Fungsi untuk menghapus produk
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $query_delete = "DELETE FROM products WHERE id='$delete_id'";
    if ($koneksi->query($query_delete)) {
        echo "<script>alert('Produk berhasil dihapus');window.location.href='stock_product.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus produk: " . $koneksi->error . "');window.location.href='stock_product.php';</script>";
    }
}

// Query untuk mendapatkan produk dan notifikasi stok
$query_products = "SELECT * FROM products";
$result_products = $koneksi->query($query_products);

// Periksa apakah query berhasil dieksekusi
if (!$result_products) {
    die('Query error: ' . $koneksi->error); // Tampilkan pesan error jika query gagal
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Stok Produk
            <small>Manajemen Stok</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Stok Produk</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <section class="col-lg-10 col-lg-offset-1">
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title">Daftar Produk</h3>
                        <a href="add_baru.php" class="btn btn-info btn-sm pull-right"><i class="fa fa-plus"></i> &nbsp Tambah Stok Baru</a>
                        <?php
                        // Periksa stok produk dan tampilkan pesan notifikasi
                        while ($row = $result_products->fetch_assoc()) {
                            if ($row['stock'] < $row['minimum_stock']) {
                                echo '<div class="alert alert-danger">Stok produk ' . $row['name'] . ' hampir habis!</div>';
                            }
                        }
                        ?>
                    </div>
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="table-datatable">
                                <thead>
                                    <tr>
                                        <th width="1%">NO</th>
                                        <th>NAMA</th>
                                        <th>DESKRIPSI</th>
                                        <th width="20%">HARGA</th>
                                        <th width="15%">STOK MINIMUM</th>
                                        <th width="15%">STOK</th>
                                        <th width="10%">AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $query = "SELECT * FROM products";
                                    $result = $koneksi->query($query);
                                    while ($d = mysqli_fetch_array($result)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $d['name']; ?></td>
                                            <td><?php echo $d['description']; ?></td>
                                            <td><?php echo $d['price']; ?></td>
                                            <td><?php echo $d['minimum_stock']; ?></td>
                                            <td><?php echo $d['stock']; ?></td>
                                            <td>
                                                <a href="stock_product.php?delete_id=<?php echo $d['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</div>

<?php include 'footer.php'; ?> 