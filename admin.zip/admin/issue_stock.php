<?php
include 'header.php'; // Sertakan header
include '../koneksi.php'; // Sertakan file koneksi

// Proses form pengeluaran barang
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Pastikan stok mencukupi sebelum mengurangi
    $query_check_stock = "SELECT stock FROM products WHERE id = ?";
    $stmt_check_stock = $koneksi->prepare($query_check_stock);
    $stmt_check_stock->bind_param('i', $product_id);
    $stmt_check_stock->execute();
    $stmt_check_stock->bind_result($current_stock);
    $stmt_check_stock->fetch();
    $stmt_check_stock->close();

    if ($current_stock < $quantity) {
        // Redirect dengan pesan error jika stok tidak mencukupi
        header("Location: issue_stock.php?error=insufficient_stock");
        exit();
    }

    // Update stok di tabel products
    $query_update = "UPDATE products SET stock = stock - ? WHERE id = ?";
    $stmt_update = $koneksi->prepare($query_update);
    $stmt_update->bind_param('ii', $quantity, $product_id);
    if ($stmt_update->execute()) {
        // Insert ke tabel stock_history
        $query_insert_history = "INSERT INTO stock_history (product_id, quantity, action_type, date) VALUES (?, ?, 'out', NOW())";
        $stmt_insert_history = $koneksi->prepare($query_insert_history);
        $stmt_insert_history->bind_param('ii', $product_id, $quantity);
        $stmt_insert_history->execute();
        $stmt_insert_history->close();
    } else {
        // Redirect dengan pesan error jika gagal
        header("Location: issue_stock.php?error=issue");
        exit();
    }
    $stmt_update->close();
}

// Query untuk mengambil daftar produk
$query_products = "SELECT id, name FROM products";
$result_products = $koneksi->query($query_products);

// Periksa apakah query berhasil dieksekusi
if (!$result_products) {
    die('Query error: ' . $koneksi->error); // Tampilkan pesan error jika query gagal
}

// Query untuk mendapatkan riwayat barang keluar
$query_history = "SELECT products.name, stock_history.quantity, stock_history.date FROM stock_history JOIN products ON stock_history.product_id = products.id WHERE stock_history.action_type = 'out' ORDER BY stock_history.date DESC";
$result_history = $koneksi->query($query_history);

// Periksa apakah query history berhasil dieksekusi
if (!$result_history) {
    die('Query error: ' . $koneksi->error); // Tampilkan pesan error jika query gagal
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Pengeluaran Barang
            <small>Barang Keluar dari Stok</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="stock_product.php">Stok Produk</a></li>
            <li class="active">Pengeluaran Barang</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <section class="col-lg-10 col-lg-offset-1">
                <div class="box box-danger">
                    <div class="box-header">
                        <h3 class="box-title">Form Pengeluaran Barang</h3>
                    </div>
                    <div class="box-body">
                        <form action="issue_stock.php" method="post">
                            <div class="form-group">
                                <label for="product_id">Pilih Produk:</label>
                                <select class="form-control" name="product_id" id="product_id" required>
                                    <option value="">Pilih Produk</option>
                                    <?php while ($row = $result_products->fetch_assoc()) : ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="quantity">Jumlah Keluar:</label>
                                <input type="number" class="form-control" name="quantity" id="quantity" required>
                            </div>
                            <button type="submit" class="btn btn-danger">Catat Pengeluaran</button>
                        </form>
                    </div>
                </div>
            </section>
        </div>

        <div class="row">
            <section class="col-lg-10 col-lg-offset-1">
                <div class="box box-danger">
                    <div class="box-header">
                        <h3 class="box-title">Riwayat Pengeluaran Barang</h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah Keluar</th>
                                    <th>Tanggal Keluar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                while ($row = $result_history->fetch_assoc()) :
                                ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $row['name']; ?></td>
                                        <td><?php echo $row['quantity']; ?></td>
                                        <td><?php echo $row['date']; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </section>
</div>

<?php include 'footer.php'; ?>