<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $invoice_id = $_POST['invoice_id'];
  $no_resi = $_POST['no_resi'];

  mysqli_query($koneksi, "UPDATE invoice SET invoice_resi='$no_resi' WHERE invoice_id='$invoice_id'");

  header("Location: transaksi.php");
  exit();
}
?>
