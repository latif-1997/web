<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rencana Pengadaan Barang</title>
    <style>
    /* Gaya CSS umum */
    body { font-family: Arial, sans-serif; }
    .kop-surat { text-align: center; margin-top: 20px; }
    .kop-surat p { margin: 0; }
    .kop-surat .nama-perusahaan { font-weight: bold; font-size: 30px; } /* Ubah ukuran font disini */
    .info-surat { margin-top: 20px; }
    .judul { text-align: center; margin-top: 30px; }
    .tanggal { margin-top: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    table, th, td { border: 1px solid black; }
    th, td { padding: 8px; text-align: left; }
    .ttd-container { margin-top: 20px; display: flex; justify-content: space-between; }
    .ttd-container p { margin-bottom: 5px; }
    .btn-cetak { margin: 20px; }

    /* CSS khusus saat dokumen di-print */
    @media print {
        .btn-cetak, form {
            display: none; /* Menyembunyikan tombol cetak dan form saat mencetak */
        }
    }
</style>
    <script>
        function printPage() {
            window.print();
        }
    </script>
</head>
<body>
    <?php
    // Generate nomor surat secara otomatis
    $nomor_surat = '001/ABC/' . date('Y');
    // Contoh nama admin, bisa diganti dengan input dari form
    $nama_admin = isset($_POST['nama_admin']) ? htmlspecialchars($_POST['nama_admin']) : 'Nama Admin';

    // Ambil data prediksi pengadaan dari URL parameter
    $tanggal_dari = isset($_GET['tanggal_dari']) ? $_GET['tanggal_dari'] : '';
    $tanggal_sampai = isset($_GET['tanggal_sampai']) ? $_GET['tanggal_sampai'] : '';
    $prediksi = isset($_GET['prediksi']) ? json_decode($_GET['prediksi'], true) : [];

    // Pastikan variabel $prediksi berisi data yang sesuai
    ?>
    

    <div class="kop-surat">
        <p class="nama-perusahaan">DIMAS Adv. Laser</p>
        <p>Jalan Sultan Hasanuddin Dalam Mal Blok M Plaza 2 No. 83-85,</p>
        <p>Kebayoran Baru, Jakarta Selatan 12160</p>
        <p>Telp./WA : 0813-1500-3378</p>
    </div>
    <div class="info-surat">
        <p>Nomor Surat: <?php echo $nomor_surat; ?></p>
        <p>Admin: <?php echo $nama_admin; ?></p>
        <p>Tanggal: <?php echo date('d-m-Y'); ?></p>
    </div>
    <div class="judul">
        <h2>Rencana Pengadaan Barang</h2>
    </div>
    <table>
        <thead>
            <tr>
                <th width="5%">NO</th>
                <th width="60%">NAMA BARANG</th>
                <th width="20%">PREDIKSI KEBUTUHAN</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($prediksi as $row) {
                echo '<tr>';
                echo '<td>' . $no++ . '</td>';
                echo '<td>' . htmlspecialchars($row['name']) . '</td>';
                echo '<td>' . round($row['quantity']) . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
    
    <div class="ttd-container">
        <div style="text-align: center; flex: 1;">
            <p>Pimpinan</p>
            <p style="margin-top: 90px;"><b>Bpk. Marsono</b></p>
        </div>
        <div style="text-align: center; flex: 1;">
            <p>Admin</p>
            <p style="margin-top: 90px;"><b><?php echo $nama_admin; ?></b></p>
        </div>
    </div>

    <!-- Form untuk input nama admin -->
    <form method="post" action="">
        <label for="nama_admin">Nama Admin:</label>
        <input type="text" id="nama_admin" name="nama_admin" required>
        <input type="submit" value="Ubah Nama Admin">
    </form>

    <!-- Tombol cetak PDF -->
    <button class="btn-cetak" onclick="printPage()">Cetak PDF</button>
</body>
</html>