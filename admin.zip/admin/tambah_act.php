<?php
include 'header.php';
include '../koneksi.php'; // Pastikan file ini berisi logika koneksi ke database

if(isset($_POST['addnewbarang'])){
    $namabarang = $_POST['namabarang'];
    $deskripsi = $_POST['deskripsi'];
    $stock = $_POST['stock'];

    $addtotable = mysqli_query($conn, "INSERT INTO stock (namabarang, deskripsi, stock) VALUES ('$namabarang', '$deskripsi', '$stock')");
    if($addtotable){
        header('location:stock_barang.php');
    } else {
        echo 'Gagal';
        header('location:stock_barang.php');
    }
}

?>

<div class="content-wrapper">

  <section class="content-header">
    <h1>
      Manajemen Stok
      <small>Stock Barang</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <section class="col-lg-10 col-lg-offset-1">
        <div class="box box-info">

          <div class="box-header">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
             Tambah Barang</button> 
          </div>
          <div class="box-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped" id="table-datatable">
                <thead>
                  <tr>
                    <th width="1%">No</th>
                    <th>Nama Barang</th>
                    <th>Deskripsi</th>
                    <th>Stock</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                $query = "SELECT * FROM stock";
                $result = mysqli_query($conn, $query);
                $no = 1;
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$no."</td>";
                    echo "<td>".$row['namabarang']."</td>";
                    echo "<td>".$row['deskripsi']."</td>";
                    echo "<td>".$row['stock']."</td>";
                    echo "</tr>";
                    $no++;
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Tambah Barang</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <form method="post" action="">
        <div class="modal-body">
          <input type="text" name="namabarang" placeholder="Nama Barang" class="form-control" required><br>
          <input type="text" name="deskripsi" placeholder="Deskripsi Barang" class="form-control" required><br>
          <input type="number" name="stock" placeholder="Stock" class="form-control" required><br>
          <button type="submit" class="btn btn-primary" name="addnewbarang">Submit</button>
        </div>
        </form>
      </div>
    </div>
</div>

<?php include 'footer.php'; ?>