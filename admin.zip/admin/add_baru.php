<?php
include 'header.php'; // Sertakan header
include '../koneksi.php'; // Sertakan file koneksi

// Fungsi untuk menambahkan produk baru
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $minimum_stock = $_POST['minimum_stock'];
    $stock = $_POST['stock'];

    // Sanitasi input
    $name = $koneksi->real_escape_string($name);
    $description = $koneksi->real_escape_string($description);
    $price = $koneksi->real_escape_string($price);
    $minimum_stock = $koneksi->real_escape_string($minimum_stock);
    $stock = $koneksi->real_escape_string($stock);

    $query_insert = "INSERT INTO products (name, description, price, minimum_stock, stock) VALUES ('$name', '$description', '$price', '$minimum_stock', '$stock')";
    if ($koneksi->query($query_insert)) {
        echo "<script>alert('Produk berhasil ditambahkan');window.location.href='stock_product.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan produk: " . $koneksi->error . "');window.location.href='stock_product.php';</script>";
    }
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Tambah Produk Baru
            <small>Manajemen Stok</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Tambah Produk Baru</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <section class="col-lg-10 col-lg-offset-1">
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title">Form Tambah Produk Baru</h3>
                    </div>
                    <div class="box-body">
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="name">Nama Produk</label>
                                <input type="text" class="form-control" name="name" placeholder="Nama Produk" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Deskripsi Produk</label>
                                <textarea class="form-control" name="description" placeholder="Deskripsi Produk" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="price">Harga Produk</label>
                                <input type="number" class="form-control" name="price" placeholder="Harga Produk" required>
                            </div>
                            <div class="form-group">
                                <label for="minimum_stock">Stok Minimum</label>
                                <input type="number" class="form-control" name="minimum_stock" placeholder="Stok Minimum" required>
                            </div>
                            <div class="form-group">
                                <label for="stock">Stok Produk</label>
                                <input type="number" class="form-control" name="stock" placeholder="Stok Produk" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Tambah Produk</button>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </section>
</div>

<?php include 'footer.php'; ?>